use std::collections::HashMap;

#[derive(Debug, Clone)]
pub struct State {
}

impl State {
    pub fn new() -> Self {
        Self {}
    }

}
